exports.signout=(req,res)=>{

    return res.json({
        message:'User SignOut'
    });
};
exports.signup=(req,res)=>{
    console.log('REQ BODY',req.body);
    return res.json({
        message:'User SignUp'
    });
};