const express=require('express');

const app=express(); 

const port=2000;

app.get('/',(req,res)=>{
    return res.send('Hello there');
});

app.get('/login',(req,res)=>{
    return res.send('Welcome this is a login page');
});


const admin=(req,res)=>{
    return res.send('This is Admin Page');
};
const isAdmin=(req,res,next)=>{
    console.log('isAdmin is running');
    next();
};
const isLoggedIn=(req,res,next)=>{
    console.log('isLoggedIn is running');
    next();
};
app.get('/admin',isLoggedIn,isAdmin,admin);

app.get('/SignUp',(req,res)=>{
    return res.send('Welcome this is a login page');
});

app.get('/SignIn',(req,res)=>{
    return res.send('your are in sign in page');
});

app.listen(port,()=>
{
    console.log('Server is up and running...');
});